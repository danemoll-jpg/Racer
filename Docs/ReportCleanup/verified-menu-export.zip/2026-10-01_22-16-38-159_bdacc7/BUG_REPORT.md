# Racer bug report

Session: 2026-10-01T22:16:38.1571550-04:00

## BUG-001

Comment:
> Menu interaction export verification

```text
Timestamp: 2026-10-01T22:16:38.1652304-04:00
Course: Mountain Loop - Forward
Direction: Forward
Mode: Free Roam
Position: X=724.51, Y=75.35, Z=-6.11
Rotation: X=0.00, Y=174.74, Z=0.00
Heading: 174.74 degrees
Viewpoint: Vehicle
Vehicle: moto
Vehicle position: X=724.51, Y=75.35, Z=-6.11
Speed: 0.00 m/s / 0.00 mph
Lap: 0 / Next checkpoint: -1
Road progress: 2631.71 m / Branch: Main / 0.00 m
Version: 0.63.0-review1 / Build: 00000000000000000000000000000000
Scene: MountainLoop
Debug movement used: False
```

![BUG-001](Screenshots/BUG-001.png)

